/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

/**
 *
 * @author hp
 */
public class UpdateAttendance{

    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }

    public String getSubejct() {
        return subejct;
    }

    public void setSubejct(String subejct) {
        this.subejct = subejct;
    }

    public String getDates() {
        return dates;
    }

    public void setDates(String dates) {
        this.dates = dates;
    }

    public UpdateAttendance(String rollno, String attendance, String subejct, String dates) {
        this.rollno = rollno;
        this.attendance = attendance;
        this.subejct = subejct;
        this.dates = dates;
    }


public UpdateAttendance()
{
    
}
   
    private String rollno;
    private String attendance;
    private String subejct;
    private String dates;
    
}
