/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

/**
 *
 * @author hp
 */
public class FeesAdd{

    public String getStudentname() {
        return studentname;
    }

    public void setStudentname(String studentname) {
        this.studentname = studentname;
    }

    public String getFathername() {
        return fathername;
    }

    public void setFathername(String fathername) {
        this.fathername = fathername;
    }

    public String getFeespay() {
        return feespay;
    }

    public void setFeespay(String feespay) {
        this.feespay = feespay;
    }

    public String getFeespaid() {
        return feespaid;
    }

    public void setFeespaid(String feespaid) {
        this.feespaid = feespaid;
    }

    public String getSubmission() {
        return submission;
    }

    public void setSubmission(String submission) {
        this.submission = submission;
    }

    public String getStudentrollno() {
        return studentrollno;
    }

    public void setStudentrollno(String studentrollno) {
        this.studentrollno = studentrollno;
    }

    public FeesAdd(String studentname, String fathername, String feespay, String feespaid, String submission, String studentrollno) {
        this.studentname = studentname;
        this.fathername = fathername;
        this.feespay = feespay;
        this.feespaid = feespaid;
        this.submission = submission;
        this.studentrollno = studentrollno;
    }
public FeesAdd()
{
    
}
  
    private String studentname;
    private String fathername;
    private String feespay;
    private String feespaid;
    private String submission;
    private String studentrollno;
    
}
