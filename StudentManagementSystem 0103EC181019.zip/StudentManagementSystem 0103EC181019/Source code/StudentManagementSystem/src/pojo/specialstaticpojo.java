/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

/**
 *
 * @author hp
 */
public class specialstaticpojo {
       
    public  specialstaticpojo()
    {
        
    }
    public static int getCount1() {
        return count1;
    }

    public static void setCount1(int count1) {
        specialstaticpojo.count1 = count1;
    }

    public static int getCount2() {
        return count2;
    }

    public static void setCount2(int count2) {
        specialstaticpojo.count2 = count2;
    }

    
    private static int count1;
    private static int count2;
}
