/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

/**
 *
 * @author hp
 */
public class AddSubject {

 

    public AddSubject() {
    }

    public static String getAddsubject() {
        return addsubject;
    }

    public static void setAddsubject(String addsubject) {
        AddSubject.addsubject = addsubject;
    }
private static String addsubject;

}
