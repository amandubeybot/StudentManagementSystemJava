/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

/**
 *
 * @author hp
 */
public class StudentAttendance {

    public StudentAttendance(String name, String rollno, String attendance, String dat, String subject) {
        this.name = name;
        this.rollno = rollno;
        this.attendance = attendance;
        this.dat = dat;
        this.subject = subject;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }

    public String getDat() {
        return dat;
    }

    public void setDat(String dat) {
        this.dat = dat;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
public StudentAttendance()
{
    
}
    

  private  String name;
  private  String rollno;
  private  String attendance;
  private  String dat;
  private String subject;
}
