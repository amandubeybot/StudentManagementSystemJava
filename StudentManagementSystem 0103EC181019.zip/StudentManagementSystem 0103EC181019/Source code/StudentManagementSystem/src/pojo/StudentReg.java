/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

/**
 *
 * @author hp
 */
public class StudentReg{

    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRepassword() {
        return repassword;
    }

    public void setRepassword(String repassword) {
        this.repassword = repassword;
    }

    public String getFathername() {
        return fathername;
    }

    public void setFathername(String fathername) {
        this.fathername = fathername;
    }

    public StudentReg(String rollno, String userid, String password, String repassword, String fathername) {
        this.rollno = rollno;
        this.userid = userid;
        this.password = password;
        this.repassword = repassword;
        this.fathername = fathername;
    }
    public StudentReg()
    {
        
    }



  private String rollno;
  private String userid;
  private String password;
  private String repassword;
  private String fathername;
    
}
