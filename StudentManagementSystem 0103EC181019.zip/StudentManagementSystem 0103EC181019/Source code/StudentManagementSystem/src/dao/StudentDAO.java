/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dbutil.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import pojo.Fees;
import pojo.FeesAdd;
import pojo.Notice;
import pojo.StudentReg;
import pojo.Password;
import pojo.Performance;
import pojo.StudentAttendance;
import pojo.UpdateAttendance;
import pojo.attendance;
import pojo.specialstaticpojo;

/**
 *
 * @author hp
 */
public class StudentDAO {
    public static int Studentreg(StudentReg reg) throws SQLException{
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("insert into users values(?,?,?,?,?)");
         ps.setString(1,reg.getUserid());
          ps.setString(2,reg.getPassword());
      ps.setString(3,"Student");
      ps.setString(4,reg.getRollno());
      ps.setString(5,reg.getFathername());
         int ji=ps.executeUpdate();
         if(ji==1)
         {
             JOptionPane.showMessageDialog(null,"succesfully inserted the record");
         }
        return ji;
             }
         
     public static int Studentpassword(Password pass) throws SQLException{
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("update users set userpassword=? where userid=?");
         ps.setString(1,pass.getUserpassword());
          ps.setString(2,pass.getUserid());

         int ji=ps.executeUpdate();
         if(ji==1)
         {
             JOptionPane.showMessageDialog(null,"succesfully updated the record");
         }
        return ji;
             }
      public static int Studentattendance(StudentAttendance reg) throws SQLException{
       
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("insert into attendance values(?,?,?,?,?)");
         ps.setString(1,reg.getName());
         
          ps.setString(2,reg.getRollno());
      ps.setString(3,reg.getAttendance());
      ps.setString(4,reg.getDat());
      ps.setString(5,reg.getSubject());
         int ji=ps.executeUpdate();
         if(ji==1)
         {
             JOptionPane.showMessageDialog(null,"succesfully inserted the record");
         }
        return ji;
             }
        public static int updateattendance(UpdateAttendance pa) throws SQLException{
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("update attendance set attend=? where rollno=? and subject=? and da=?");
         ps.setString(1,pa.getAttendance());
          ps.setString(2,pa.getRollno());
          ps.setString(3,pa.getSubejct());
          ps.setString(4,pa.getDates());

         int ji=ps.executeUpdate();
         if(ji==1)
         {
             JOptionPane.showMessageDialog(null,"succesfully updated the record");
         }
        return ji;
             } 
        public static ArrayList<StudentAttendance> getAlldata() throws SQLException
    {
         Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select * from attendance");
        ResultSet rs=ps.executeQuery();
        ArrayList<StudentAttendance> pr=new ArrayList<StudentAttendance>();
        while(rs.next())
        {
            String user=rs.getString(1);
            String exam=rs.getString(2);
            String rig=rs.getString(3);
             String wro=rs.getString(4);
              String wr=rs.getString(5);
            StudentAttendance prt;
             prt = new StudentAttendance(user,exam,rig,wro,wr);
            pr.add(prt);
            }
        return pr;
       }
         public static int Studentfees(FeesAdd reg) throws SQLException{
       
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("insert into fees values(?,?,?,?,?,?)");
         ps.setString(1,reg.getStudentname());
          ps.setString(2,reg.getFathername());
      ps.setString(3,reg.getFeespay());
      ps.setString(4,reg.getFeespaid());
      ps.setString(5,reg.getSubmission());
      ps.setString(6,reg.getStudentrollno());
         int ji=ps.executeUpdate();
         if(ji==1)
         {
             JOptionPane.showMessageDialog(null,"succesfully inserted the record");
         }
        return ji;
             }
          public static int updatefees(FeesAdd reg) throws SQLException{
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("update fees set feespay=?,feespaid=?,dates=? where srollno=?");
     String rt=reg.getFeespay();
     String ty=reg.getFeespaid(); 
      String hj= reg.getSubmission();
       String ki=reg.getStudentrollno();
              System.out.println("==== "+rt);
               System.out.println("==== "+ty);
                System.out.println("===="+hj);
                 System.out.println("==== "+ki);
      ps.setString(1,reg.getFeespay());
      ps.setString(2,reg.getFeespaid());
      ps.setString(3,reg.getSubmission());
      ps.setString(4,reg.getStudentrollno());
         int ji=ps.executeUpdate();
         if(ji==1)
         {
             JOptionPane.showMessageDialog(null,"succesfully updated the record");
         }
        return ji;
             } 
 
public static ArrayList<FeesAdd> getAllFees() throws SQLException
    {
         Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select * from fees");
        ResultSet rs=ps.executeQuery();
        ArrayList<FeesAdd> pr=new ArrayList<FeesAdd>();
        while(rs.next())
        {
            String user=rs.getString(1);
            String exam=rs.getString(2);
            String rig=rs.getString(3);
             String wro=rs.getString(4);
              String righ=rs.getString(5);
             String wron=rs.getString(6);
        
           FeesAdd prt;
             prt = new FeesAdd(user,exam,rig,wro,righ,wron);
            pr.add(prt);
            }
        return pr;
       }
 public static ArrayList<StudentAttendance> getSigleSubjectwiseAttendance(attendance rt) throws SQLException
    {        int counta=0;
             int countb=0;
             String rig;
         Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select * from attendance where userid=? and rollno=?");
        ps.setString(1,rt.getStudentid());
         ps.setString(2,rt.getStudentrollno());
        ResultSet rs=ps.executeQuery();
        ArrayList<StudentAttendance> pr=new ArrayList<StudentAttendance>();
        while(rs.next())
        {
            String user=rs.getString(1);
            String exam=rs.getString(2);
             rig=rs.getString(3);
            if(rig.equalsIgnoreCase("present"))
            {
                counta++;
            }
           
             
            String wro=rs.getString(4);
            String wr=rs.getString(5);
            countb++;
            StudentAttendance prt;
             prt = new StudentAttendance(user,exam,rig,wro,wr);
            pr.add(prt);
            }
        specialstaticpojo.setCount1(counta);
        specialstaticpojo.setCount2(countb);
        return pr;
}
 public static ArrayList<FeesAdd> getSigleFees(Fees rt) throws SQLException
    {      
         Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select * from fees where studentname=? and srollno=?");
        ps.setString(1,rt.getUserid());
         ps.setString(2,rt.getRollno());
        ResultSet rs=ps.executeQuery();
        ArrayList<FeesAdd> pr=new ArrayList<FeesAdd>();
        while(rs.next())
        {
            String user=rs.getString(1);
            String exam=rs.getString(2);
             String rig=rs.getString(3);
       
             
            String wro=rs.getString(4);
            String wr=rs.getString(5); 
            String rr=rs.getString(6);
            
            
            FeesAdd prt;
             prt = new FeesAdd(user,exam,rig,wro,wr,rr);
            pr.add(prt);
            }
 
        return pr;
}
   public static int AddNotice(Notice re) throws SQLException{
       
         Connection conn=DBConnection.getConnection();
         PreparedStatement ps=conn.prepareStatement("update notice set noti=?");
         ps.setString(1,re.getNotice());
    
         int ji=ps.executeUpdate();
         if(ji==1)
         {
             JOptionPane.showMessageDialog(null,"succesfully Added the Notice");
         }
        return ji;
             }
     public static String getAllNotice() throws SQLException
    {
         Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("select * from notice");
        ResultSet rs=ps.executeQuery();
        Notice ob=new Notice();
        String  us = null;
        while(rs.next())
        {
             us=rs.getString(1);
       
            System.out.println("student dao givea the getstring as the ---------"+us);
    
     
          
            }
       
       return us;
       
       
       }
}
